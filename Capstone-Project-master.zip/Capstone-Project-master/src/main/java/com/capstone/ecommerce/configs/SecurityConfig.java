package com.capstone.ecommerce.configs;public class SecurityConfig {
}
