package com.capstone.ecommerce.dtos;public class AddressDTO {
}
