package com.capstone.ecommerce.mappers;public interface AddressMapper {
}
