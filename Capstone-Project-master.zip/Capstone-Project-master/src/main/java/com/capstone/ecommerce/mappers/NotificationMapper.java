package com.capstone.ecommerce.mappers;public interface NotificationMapper {
}
