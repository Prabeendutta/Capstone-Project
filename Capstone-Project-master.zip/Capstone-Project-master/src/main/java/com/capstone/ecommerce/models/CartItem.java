package com.capstone.ecommerce.models;public class CartItem {
}
