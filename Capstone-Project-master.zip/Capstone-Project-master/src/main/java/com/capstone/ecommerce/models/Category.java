package com.capstone.ecommerce.models;public class Category {
}
