package com.capstone.ecommerce.repositories;public interface AddressRepository {
}
