package com.capstone.ecommerce.repositories;public class CartRepository {
}
